<?php
if(session_id() == '') session_start(); //print_r($_SESSION);
if (isset($_SESSION['login_user'])==false) {
    header("location:dangnhap.php");
    exit();
} 
$tendangnhap = $_SESSION['login_user'];
?>
<!Doctype html>
<html>
    <form>
        <div class = "mk">
            <label for="tendangnhap" class="form-lable">Tên đăng nhập</label>
            <input type="text" class="form-control" id="tendangnhap" name="tendangnhap">
        </div>
    </form>
</html>